public class Configs {
    public String configs[];
}