class Metric {
	String name;
	String sourceComponent;
	double value;
	int count;
	boolean preferHigh;
}

class Event {
	String name;
	String sourceComponent;
	double value;
	int count;
}

public class PerceptionData {
    public Metric metrics[];
	public Event events[];
}